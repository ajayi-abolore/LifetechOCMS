-- PHP MySQL Dump
--
-- Host: 
-- Generated: Sat, 21 Jan 2023 08:39:33 +0100
-- PHP Version: 8.1.10

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";;;;;_lifetechend;;;;;

--
-- Database: `lifetechocms`
--
